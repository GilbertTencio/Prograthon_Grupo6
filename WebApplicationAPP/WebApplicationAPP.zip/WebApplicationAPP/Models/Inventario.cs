﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplicationAPP.Models
{
    [Table("Inventario_GilbertTencio")]
    public class Inventario
    {
        public int Id { get; set; }

        public string Nombre { get; set; }

        public string Descripcion { get; set; }

        public decimal Precio { get; set; }

        public int Stock { get; set; }

        public string Categoria { get; set; }

        [Column("Fecha_registro")]
        public DateTime FechaRegistro { get; set; }

        public bool Activo { get; set; }
    }
}
