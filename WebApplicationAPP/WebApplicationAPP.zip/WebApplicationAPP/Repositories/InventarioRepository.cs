﻿using WebApplicationAPP.Data;
using WebApplicationAPP.Models;

namespace WebApplicationAPP.Repositories
{
    public class InventarioRepository : IInventarioRepository
    {
        private readonly AppDbContext _context;

        public InventarioRepository(AppDbContext context)
        {
            _context = context;
        }

        public List<Inventario> GetAll()
        {
            return _context.Inventario.ToList();
        }

        public Inventario GetById(int id)
        {
            return _context.Inventario.Find(id);
        }

        public void Add(Inventario inventario)
        {
            _context.Inventario.Add(inventario);
            _context.SaveChanges();
        }

        public void Update(Inventario inventario)
        {
            _context.Inventario.Update(inventario);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var inventario = GetById(id);
            if (inventario != null)
            {
                _context.Inventario.Remove(inventario);
                _context.SaveChanges();
            }
        }
    }
}
