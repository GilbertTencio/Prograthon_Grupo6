﻿using Microsoft.AspNetCore.Mvc;
using WebApplicationAPP.Bussines;
using WebApplicationAPP.Models;

namespace WebApplicationAPP.Controllers
{
    public class InventarioController : Controller
    {
        private readonly InventarioBusiness _inventarioBusiness;

        public InventarioController(InventarioBusiness inventarioBusiness)
        {
            _inventarioBusiness = inventarioBusiness;
        }

        public IActionResult Index()
        {
            return View(_inventarioBusiness.GetAll());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Inventario inventario)
        {
            if (!ModelState.IsValid)
                return View(inventario);

            inventario.FechaRegistro = DateTime.Now;
            _inventarioBusiness.Add(inventario);

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            return View(_inventarioBusiness.GetById(id));
        }

        [HttpPost]
        public IActionResult Edit(Inventario inventario)
        {
            _inventarioBusiness.Update(inventario);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(int id)
        {
            return View(_inventarioBusiness.GetById(id));
        }

        public IActionResult Delete(int id)
        {
            return View(_inventarioBusiness.GetById(id));
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            _inventarioBusiness.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
