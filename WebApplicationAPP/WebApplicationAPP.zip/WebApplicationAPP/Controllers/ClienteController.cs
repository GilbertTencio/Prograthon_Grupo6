﻿using Microsoft.AspNetCore.Mvc;
using WebApplicationAPP.Bussines;
using WebApplicationAPP.Models;

namespace WebApplicationAPP.Controllers
{
    public class ClienteController : Controller
    {
        private readonly ClienteBusiness _clienteBusiness;

        public ClienteController(ClienteBusiness clienteBusiness)
        {
            _clienteBusiness = clienteBusiness;
        }

        public IActionResult Index()
        {
            return View(_clienteBusiness.GetAll());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Cliente cliente)
        {
            if (!ModelState.IsValid)
                return View(cliente);

            cliente.FechaRegistro = DateTime.Now;
            _clienteBusiness.Add(cliente);

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            return View(_clienteBusiness.GetById(id));
        }

        [HttpPost]
        public IActionResult Edit(Cliente cliente)
        {
            _clienteBusiness.Update(cliente);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Details(int id)
        {
            return View(_clienteBusiness.GetById(id));
        }

        public IActionResult Delete(int id)
        {
            return View(_clienteBusiness.GetById(id));
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirm(int id)
        {
            _clienteBusiness.Delete(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
